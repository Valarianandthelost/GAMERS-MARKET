const productIndex = localStorage.getItem('productIndex');
const products = [
  {
    name: "Sample Product 1",
    description: "High quality product",
    image: "images/product1.jpg"
  },
  {
    name: "Sample Product 2",
    description: "Another great item",
    image: "images/product2.jpg"
  }
];

function loadProduct() {
  const container = document.getElementById('productContainer');
  const product = products[productIndex];
  container.innerHTML = `
    <img src="${product.image}" alt="${product.name}" style="width:100%; max-width:400px;"/>
    <h2>${product.name}</h2>
    <p>${product.description}</p>
    <button onclick="orderProduct('${product.image}')">For Order</button>
  `;
}

function orderProduct(image) {
  localStorage.setItem('orderImage', image);
  window.location.href = 'order.html';
}

window.onload = loadProduct;
