const products = [
  {
    name: "Sample Product 1",
    description: "High quality product",
    image: "images/product1.jpg"
  },
  {
    name: "Sample Product 2",
    description: "Another great item",
    image: "images/product2.jpg"
  }
];

function loadProducts() {
  const grid = document.getElementById('productGrid');
  const searchInput = document.getElementById('searchInput');

  function displayProducts(filter = "") {
    grid.innerHTML = "";
    products.filter(p => p.name.toLowerCase().includes(filter.toLowerCase())).forEach((product, index) => {
      const div = document.createElement('div');
      div.className = 'product-card';
      div.innerHTML = `
        <img src="${product.image}" alt="${product.name}"/>
        <h3>${product.name}</h3>
        <button onclick="viewProduct(${index})">View</button>
      `;
      grid.appendChild(div);
    });
  }

  searchInput.addEventListener('input', () => {
    displayProducts(searchInput.value);
  });

  displayProducts();
}

function viewProduct(index) {
  localStorage.setItem('productIndex', index);
  window.location.href = 'product.html';
}

function closePopup() {
  document.getElementById('popup').style.display = 'none';
}

window.onload = loadProducts;
